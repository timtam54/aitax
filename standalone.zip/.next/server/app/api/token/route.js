var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/token/route.js")
R.c("server/chunks/[root-of-the-server]__465cc31a._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_token_route_actions_0f0e8cc7.js")
R.m(60642)
module.exports=R.m(60642).exports
