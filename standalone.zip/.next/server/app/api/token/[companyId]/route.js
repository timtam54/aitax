var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/token/[companyId]/route.js")
R.c("server/chunks/[root-of-the-server]__1fd30674._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_token_[companyId]_route_actions_e57332b4.js")
R.m(34191)
module.exports=R.m(34191).exports
