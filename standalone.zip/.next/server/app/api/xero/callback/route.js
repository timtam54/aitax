var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/xero/callback/route.js")
R.c("server/chunks/[root-of-the-server]__86241539._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_xero_callback_route_actions_40c94874.js")
R.m(13045)
module.exports=R.m(13045).exports
