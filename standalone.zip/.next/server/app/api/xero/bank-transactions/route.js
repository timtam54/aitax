var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/xero/bank-transactions/route.js")
R.c("server/chunks/[root-of-the-server]__9991bce7._.js")
R.c("server/chunks/[root-of-the-server]__5f7b972c._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_xero_bank-transactions_route_actions_db0233db.js")
R.m(78288)
module.exports=R.m(78288).exports
