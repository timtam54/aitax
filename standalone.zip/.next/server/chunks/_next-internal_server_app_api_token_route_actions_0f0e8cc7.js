module.exports=[64215,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_token_route_actions_0f0e8cc7.js.map