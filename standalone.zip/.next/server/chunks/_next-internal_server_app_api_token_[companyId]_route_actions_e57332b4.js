module.exports=[3587,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_token_%5BcompanyId%5D_route_actions_e57332b4.js.map