module.exports=[34471,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_xero_page_actions_2f63c200.js.map