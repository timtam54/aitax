globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/9563dab5ba30607d.js",
    "static/chunks/256659360a5e7c6b.js",
    "static/chunks/6740f161f60c6ab5.js",
    "static/chunks/8368f298651cbd89.js",
    "static/chunks/turbopack-8c3295d02607ed86.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];